<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order Item</title>
</head>
<body>
    <h1>Order Item</h1>
    <form method="post" action="">
        Item name: <input type="text" name="Item_name"><br>
        Order amount in KG: <input type="text" name="amount"><br>
        <input type="submit" value="Order">
    </form>

    <?php
	
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database configuration
        $host = 'localhost'; // Your database host
        $dbname = 'msp'; // Your database name
        $username = 'root'; // Your database username
        $password = ''; // Your database password

        // Create a MySQLi connection
        $conn = new mysqli($host, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Get the values from the form
        $itemName = mysqli_real_escape_string($conn, $_POST["Item_name"]);
        $amount = mysqli_real_escape_string($conn, $_POST["amount"]);
        $amountInt = intval($amount);

        // Retrieve the existing amount from the database
        $query = "SELECT item_amount_in_kg FROM items WHERE item_name = '$itemName'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $existingAmount = intval($row["item_amount_in_kg"]);

            // Calculate the new total amount
            $newTotalAmount = $existingAmount + $amountInt;

            // Update the database with the new total amount
            $updateQuery = "UPDATE items SET item_amount_in_kg = $newTotalAmount WHERE item_name = '$itemName'";
            if ($conn->query($updateQuery) === TRUE) {
                echo "Order placed successfully. New total amount: $newTotalAmount KG.";
            } else {
                echo "Error updating record: " . $conn->error;
            }
        } else {
            echo "Item not found in the database.";
        }

        // Close the database connection
        $conn->close();
    }
    ?>
</body>
</html>

<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>GotoGro</title>
</head>
<body>
    <header>
        <h1>Welcome to GotoGro</h1>
    </header>
    <div class="container">
        <div class="options">
            <a class="option" href="purchase.php?fromHomepage=true">Customer Purchase</a></br>
            <a class="option" href="editSalesRecord.php?fromHomepage=true">Modify a sales record</a></br>
            <a class="option" href="removeSalesRecord.php?fromHomepage=true">Remove a Salesrecord</a></br>
			<a class="option" href="ViewSalesRecord.php?fromHomepage=true">View Sales Record</a></br>
			<a class="option" href="analyseByDate.php?fromHomepage=true">Analyse Sales by Date</a></br>
			<a class="option" href="analysememberGroceryNeeds.php?fromHomepage=true">Analyse Member Grocery Needs</a></br>
		    <a class="option" href="csv.php?fromHomepage=true">Export Sales record to CSV</a>
			
        </div>
    </div>
</body>
</html>

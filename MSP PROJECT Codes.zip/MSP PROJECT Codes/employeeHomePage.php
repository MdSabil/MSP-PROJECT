<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>GotoGro</title>
</head>
<body>
    <header>
        <h1>Welcome to GotoGro</h1>
    </header>
    <div class="container">
        <div class="options">
            <a class="option" href="manageMember.php?fromHomepage=true">Manage Members</a></br>
            <a class="option" href="order_item.php?fromHomepage=true">Order Items</a></br>
            <a class="option" href="manage_sales.php?fromHomepage=true">Manage and Analyze Sales</a>
        </div>
    </div>
</body>
</html>

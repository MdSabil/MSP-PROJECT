<?php
if (!isset($_GET['fromManageMember']) || $_GET['fromManageMember'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: employeeHomePage.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Member</title>
</head>
<body>
    <h1>Add Member</h1>
    <form method="post" action="">
        First Name: <input type="text" name="first_name" pattern="[A-Za-z\s]+" required><br>
        Last Name: <input type="text" name="last_name" pattern="[A-Za-z\s]+" required><br>
        Phone Number: <input type="text" name="phone_number" pattern="[0-9\s]{1,12}" required><br>
        Email: <input type="email" name="email" required><br>
        Address: <input type="text" name="address" required><br>
        <input type="submit" value="Add Member">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database configuration
        $host = 'localhost'; // Your database host
        $dbname = 'msp'; // Your database name
        $username = 'root'; // Your database username
        $password = ''; // Your database password

        // Create a MySQLi connection
        $conn = new mysqli($host, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Sanitize and validate form inputs
        $first_name = mysqli_real_escape_string($conn, $_POST["first_name"]);
        $last_name = mysqli_real_escape_string($conn, $_POST["last_name"]);
        $phone_number = mysqli_real_escape_string($conn, $_POST["phone_number"]);
        $email = mysqli_real_escape_string($conn, $_POST["email"]);
        $address = mysqli_real_escape_string($conn, $_POST["address"]);

        // Improved email validation using filter_var
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Insert data into the database
            $sql = "INSERT INTO members (first_name, last_name, phone_number, email, address) VALUES ('$first_name', '$last_name', '$phone_number', '$email', '$address')";

            if ($conn->query($sql) === TRUE) {
                // Retrieve the maximum member ID
                $memberIDQuery = "SELECT MAX(member_id) AS max_id FROM members";
                $memberIDResult = $conn->query($memberIDQuery);

                if ($memberIDResult->num_rows > 0) {
                    $row = $memberIDResult->fetch_assoc();
                    $maxMemberID = $row["max_id"];
                    echo "Welcome to GotoGro $first_name $last_name. Your member ID is: $maxMemberID";
                } else {
                    echo "Error retrieving member ID.";
                }
            } else {
                echo "Error: " . $conn->error;
            }
        } else {
            echo "Invalid email address. Please enter a valid email.";
        }

        // Close the database connection
        $conn->close();
    }
    ?>
</body>
</html>

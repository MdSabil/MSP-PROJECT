<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
// Database connection parameters
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$date_from = "";
$date_to = "";
$sold_products = array();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["date_from"]) && isset($_POST["date_to"])) {
    $date_from = $_POST["date_from"];
    $date_to = $_POST["date_to"];

    // SQL query to retrieve sold products and their quantities within the date range
    $sql = "SELECT s.item_id, i.item_name, SUM(s.amount) AS total_sold
            FROM salesrecor s
            JOIN items i ON s.item_id = i.item_id
            WHERE s.date_purchased BETWEEN ? AND ?
            GROUP BY s.item_id, i.item_name";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $date_from, $date_to); // "ss" represents two string parameters

    // Execute the prepared statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $item_id = $row["item_id"];
            $item_name = $row["item_name"];
            $total_sold = $row["total_sold"];
            $sold_products[] = array("item_id" => $item_id, "item_name" => $item_name, "total_sold" => $total_sold);
        }
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sold Products and Amount</title>
</head>
<body>
    <h2>Sold Products and Amount</h2>
    <form method="post" action="">
        From Date: <input type="date" name="date_from" value="<?php echo $date_from; ?>"><br>
        To Date: <input type="date" name="date_to" value="<?php echo $date_to; ?>"><br>
        <input type="submit" value="Calculate">
    </form>
    <?php
    if (!empty($sold_products)) {
        echo "<h3>Products Sold from $date_from to $date_to:</h3>";
        echo "<table>";
        echo "<tr><th>Item ID</th><th>Item Name</th><th>Total Sold</th></tr>";
        foreach ($sold_products as $product) {
            echo "<tr><td>{$product['item_id']}</td><td>{$product['item_name']}</td><td>{$product['total_sold']}</td></tr>";
        }
        echo "</table>";
    }
    ?>
</body>
</html>

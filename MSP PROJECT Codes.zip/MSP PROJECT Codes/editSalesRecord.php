<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}

// Database configuration
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a MySQLi connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sales_record_id = $_POST["sales_record_id"];
    $field_to_update = $_POST["field_to_update"];
    $new_value = $_POST["new_value"];

    // Check if the sales_record_id is provided
    if (!empty($sales_record_id)) {
        // Check if the sales record ID exists in the database
        $checkQuery = "SELECT sales_record_id FROM salesrecor WHERE sales_record_id = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("i", $sales_record_id); // "i" represents an integer
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            if (!empty($field_to_update) && !empty($new_value)) {
                // Use prepared statements to prevent SQL injection
                $updateQuery = "UPDATE salesrecor SET $field_to_update = ? WHERE sales_record_id = ?";
                $stmt = $conn->prepare($updateQuery);
                $stmt->bind_param("si", $new_value, $sales_record_id); // "si" represents a string and an integer

                if ($stmt->execute()) {
                    echo "Sales record with ID $sales_record_id has been updated.";
                } else {
                    echo "Error updating sales record: " . $stmt->error;
                }

                $stmt->close();
            } else {
                echo "Please select a field to update and provide a new value.";
            }
        } else {
            echo "Sales record with ID $sales_record_id does not exist in the database.";
        }
        $checkStmt->close();
    } else {
        echo "Please enter a valid sales_record_id.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Sales Record</title>
</head>
<body>
    <h2>Edit Sales Record</h2>
    <form method="post" action="">
        Sales Record ID: <input type="text" name="sales_record_id"><br>
        Field to Update:
        <select name="field_to_update">
            <option value="member_id">Member ID</option>
            <option value="item_id">Item ID</option>
            <option value="amount">Amount</option>
            <option value="date_purchased">Date Purchased</option>
            <option value="Amount_spent">Amount Spent</option>
        </select><br>
        New Value: <input type="text" name="new_value"><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>

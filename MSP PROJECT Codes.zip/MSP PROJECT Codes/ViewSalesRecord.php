<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
// Database connection parameters
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to hold form input values
$date = "";
$member_id = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST["date"];
    $member_id = $_POST["member_id"];

    // Build the SQL query based on form input
    $sql = "SELECT * FROM salesrecor WHERE 1=1";

    if (!empty($date)) {
        $sql .= " AND date_purchased = '$date'";
    }

    if (!empty($member_id)) {
        $sql .= " AND member_id = $member_id";
    }

    // Execute the SQL query
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>Sales Records</h2>";
        echo "<table border='1'>";
        echo "<tr><th>sales_record_id</th><th>member_id</th><th>item_id</th><th>amount</th><th>date_purchased</th><th>Amount_spent</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["sales_record_id"] . "</td>";
            echo "<td>" . $row["member_id"] . "</td>";
            echo "<td>" . $row["item_id"] . "</td>";
            echo "<td>" . $row["amount"] . "</td>";
            echo "<td>" . $row["date_purchased"] . "</td>";
            echo "<td>" . $row["Amount_spent"] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "No records found.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Sales Records</title>
</head>
<body>
    <h2>View Sales Records</h2>
    <form method="post" action="">
        Date: <input type="date" name="date" value="<?php echo $date; ?>"><br>
        Member ID: <input type="text" name="member_id" value="<?php echo $member_id; ?>"><br>
        <input type="submit" value="Search">
    </form>
</body>
</html>

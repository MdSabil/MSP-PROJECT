<?php
if (!isset($_GET['fromManageMember']) || $_GET['fromManageMember'] !== 'true') {
    // If the 'fromManageMember' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
// Database configuration
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a MySQLi connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$memberId = ''; // Member ID for which the award is granted
$grantAward = false; // Flag to indicate whether an award can be granted

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get member ID from the form
    $memberId = $_POST["member_id"];

    // Check if the member has at least 50 points
    $query = "SELECT member_point FROM member_point WHERE member_id = $memberId";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $memberPoints = intval($row["member_point"]);

        if ($memberPoints >= 50) {
            // Member has enough points for the award
            $grantAward = true;

            // Deduct 50 points from the member
            $newPoints = $memberPoints - 50;
            $updateQuery = "UPDATE member_point SET member_point = $newPoints WHERE member_id = $memberId";
            $conn->query($updateQuery);
        }
		else 
		{
			echo "insuffienct member points";
		}
    }
}


// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Award Management</title>
</head>
<body>
    <h1>Award Management</h1>
    <form method="post" action="">
        Member ID: <input type="text" name="member_id" value="<?php echo $memberId; ?>">
        <input type="submit" value="Grant Award">
    </form>

    <?php if ($grantAward) { ?>
        <p>Award granted. 50 points deducted from Member ID: <?php echo $memberId; ?></p>
    <?php } ?>
</body>
</html>

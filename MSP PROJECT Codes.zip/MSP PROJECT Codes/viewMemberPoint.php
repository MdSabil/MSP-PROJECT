<?php
if (!isset($_GET['fromManageMember']) || $_GET['fromManageMember'] !== 'true') {
    // If the 'fromManageMember' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
// Database configuration
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a MySQLi connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$memberId = '';
$showAll = false;
$members = array();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get member ID from the form
    $memberId = $_POST["member_id"];

    if (!empty($memberId)) {
        $query = "SELECT * FROM member_point WHERE member_id = $memberId";
    } else {
        $showAll = true;
        $query = "SELECT * FROM member_point";
    }

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $members[] = $row;
        }
    } else {
        echo "No records found";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Member Points</title>
</head>
<body>
    <h1>View Member Points</h1>
    <form method="post" action="">
        Member ID: <input type="text" name="member_id" value="<?php echo $memberId; ?>">
        <input type="submit" value="Submit">
    </form>

    <?php if (!empty($members)) { ?>
        <table>
            <tr>
                <th>Member ID</th>
                <th>Member Points</th>
            </tr>
            <?php foreach ($members as $member) { ?>
                <tr>
                    <td><?php echo $member["member_id"]; ?></td>
                    <td><?php echo $member["member_point"]; ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else if ($showAll) { ?>
        <p>No records found for Member ID: <?php echo $memberId; ?></p>
    <?php } ?>
</body>
</html>

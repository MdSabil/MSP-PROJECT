<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
</head>
<body>
    <h2>Welcome to GotoGro</h2>
    <h2>Login</h2>
    <form method="post" action="">
        <label for="username">Username:</label>
        <input type="text" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br><br>

        <input type="submit" value="Login">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection information
        $host = "localhost";
        $username = "root";
        $password = "";
        $database = "msp"; // Change to your database name

        // Connect to the database
        $mysqli = new mysqli($host, $username, $password, $database);

        if ($mysqli->connect_error) {
            die("Connection failed: " . $mysqli->connect_error);
        }

        // Get user input
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Query to check if user exists
        $query = "SELECT * FROM employee WHERE username = ? AND PASSWORD = ?";

        if ($stmt = $mysqli->prepare($query)) {
            $stmt->bind_param("ss", $username, $password);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                // Authentication successful
                echo "Login successful. Redirect to your welcome page.";
                // You can set a session or redirect the user to a welcome page here.
				 header("Location: employeeHomePage.php?fromHomepage=true");
            exit(); // Important to stop further execution.
            } else {
                // Authentication failed
                echo "Login failed. Invalid username or password.";
            }

            $stmt->close();
        } else {
            // Error in the prepared statement
            echo "Error: " . $mysqli->error;
        }

        $mysqli->close();
    }
    ?>
</body>
</html>



<?php include 'db_config.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Sale Record</title>
</head>
<body>
    <h1>Add Sale Record</h1>
    <form method="POST" action="process_sale_record.php">
        <label>Date:</label>
        <input type="date" name="date" required><br>

        <label>Customer Name:</label>
        <input type="text" name="customer_name" required><br>

        <label>Product:</label>
        <input type="text" name="product" required><br>

        <label>Quantity:</label>
        <input type="number" name="quantity" required><br>

        <label>Price:</label>
        <input type="number" step="0.01" name="price" required><br>


        

        <label>Invoice Number:</label>
        <input type="text" name="invoice_number" required><br>

        

        


        <input type="submit" value="Add Sale Record">
    </form>
</body>
</html>
<?php
if (!isset($_GET['fromManageMember']) || $_GET['fromManageMember'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: employeeHomePage.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Remove Member</title>
</head>
<body>
    <h1>Remove Member</h1>
    <?php
    $host = 'localhost'; // Your database host (e.g., localhost)
    $dbname = 'msp'; // Your database name
    $username = 'root'; // Your database username
    $password = ''; // Your database password

    // Create a MySQLi connection
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Sanitize and validate form inputs
        $member_id = $_POST["member_id"];

        // First, retrieve the first name and last name
        $FirstNameQuery = "SELECT first_name FROM members WHERE member_id='$member_id'";
        $LastNameQuery = "SELECT last_name FROM members WHERE member_id='$member_id'";

        $FirstNameResult = $conn->query($FirstNameQuery);
        $LastNameResult = $conn->query($LastNameQuery);

        if ($FirstNameResult && $LastNameResult) {
            $firstNameRow = $FirstNameResult->fetch_assoc();
            $lastNameRow = $LastNameResult->fetch_assoc();

            $firstName = $firstNameRow['first_name'];
            $lastName = $lastNameRow['last_name'];

            // Delete the member
            $sql = "DELETE FROM members WHERE member_id='$member_id'";

            if ($conn->query($sql) === TRUE) {
                echo "Goodbye $firstName $lastName!";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

            // Close the result sets
            $FirstNameResult->close();
            $LastNameResult->close();
        } else {
            echo "Error fetching member details: " . $conn->error;
        }
    }
    ?>

    <form method="post" action="">
        Member ID: <input type="text" name="member_id"><br>
        <input type="submit" value="Remove">
    </form>
</body>
</html>

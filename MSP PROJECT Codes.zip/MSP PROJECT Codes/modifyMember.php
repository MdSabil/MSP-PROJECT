<?php
if (!isset($_GET['fromManageMember']) || $_GET['fromManageMember'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: employeeHomePage.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Modify Member</title>
</head>
<body>
    <h1>Modify Member</h1>

    <?php
    $host = 'localhost'; // Your database host (e.g., localhost)
    $dbname = 'msp'; // Your database name
    $username = 'root'; // Your database username
    $password = ''; // Your database password

    // Create a MySQLi connection
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Sanitize and validate form inputs
        $member_id = $_POST["member_id"];
        $field_to_update = $_POST["field_to_update"];
        $new_value = mysqli_real_escape_string($conn, $_POST["new_value"]);

        // Construct the SQL query to update the specified field
        if ($field_to_update == "first_name" && preg_match("/^[A-Za-z\s]+$/", $new_value)) {
            $sql = "UPDATE members SET $field_to_update='$new_value' WHERE member_id='$member_id'";
        } else if ($field_to_update == "first_name" && !preg_match("/^[A-Za-z\s]+$/", $new_value)) {
            echo "Sorry, name is wrong.";
        } else if ($field_to_update == "last_name" && preg_match("/^[A-Za-z\s]+$/", $new_value)) {
            $sql = "UPDATE members SET $field_to_update='$new_value' WHERE member_id='$member_id'";
        } else if ($field_to_update == "last_name" && !preg_match("/^[A-Za-z\s]+$/", $new_value)) {
            echo "Sorry, name is wrong.";
        } else if ($field_to_update == "phone_number" && preg_match("/^[0-9\s]{1,12}$/", $new_value)) {
            $sql = "UPDATE members SET $field_to_update='$new_value' WHERE member_id='$member_id'";
        } else if ($field_to_update == "phone_number" && !preg_match("/^[0-9\s]{1,12}$/", $new_value)) {
            echo "Sorry, the phone number is wrong.";
        } else if ($field_to_update == "email" && filter_var($new_value, FILTER_VALIDATE_EMAIL)) {
            $sql = "UPDATE members SET $field_to_update='$new_value' WHERE member_id='$member_id'";
        } else if ($field_to_update == "email" && !filter_var($new_value, FILTER_VALIDATE_EMAIL)) {
            echo "Sorry, the email address is invalid.";
        }

        if (isset($sql)) {
            if ($conn->query($sql) === TRUE) {
                echo "$field_to_update of member $member_id is updated to $new_value!";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }

    // Close the database connection
    $conn->close();
    ?>

    <form method="post" action="">
        Member ID: <input type="text" name="member_id"><br>

        <label for="field_to_update">Select Field to Update:</label>
        <select name="field_to_update">
            <option value="first_name">First Name</option>
            <option value="last_name">Last Name</option>
            <option value="phone_number">Phone Number</option>
            <option value="email">Email</option>
            <option value="address">Address</option>
        </select><br>

        New Value: <input type="text" name="new_value" required>
        <input type="submit" value="Update">
    </form>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Add Member</title>
</head>
<body>
    <h1>Add Member</h1>
    <form method="post" action="">
        First Name: <input type="text" name="first_name" required><br>
        Last Name:  <input type="text" name="last_name" required><br>
        Phone Number: <input type="text" name="phone_number" required><br>
        Email: <input type="text" name="email" required><br>
        Address: <input type="text" name="address" required><br>
        <input type="submit" value="Add Member">
    </form>

    <?php
    $host = 'localhost'; // Your database host (e.g., localhost)
    $dbname = 'msp'; // Your database name
    $username = 'root'; // Your database username
    $password = ''; // Your database password

    // Create a MySQLi connection
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Sanitize and validate form inputs
        $first_name = mysqli_real_escape_string($conn, $_POST["first_name"]);
        $last_name = mysqli_real_escape_string($conn, $_POST["last_name"]);
        $phone_number = mysqli_real_escape_string($conn, $_POST["phone_number"]);
        $email = mysqli_real_escape_string($conn, $_POST["email"]);
        $address = mysqli_real_escape_string($conn, $_POST["address"]);

        // Insert data into the database
        $sql = "INSERT INTO members (first_name, last_name, phone_number, email, address) VALUES ('$first_name', '$last_name', '$phone_number', '$email', '$address')";

        if ($conn->query($sql) === TRUE) {
            echo "Data added to the database successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Close the database connection
    $conn->close();
    ?>
</body>
</html>
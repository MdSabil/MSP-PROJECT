<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Member</title>
</head>
<body>
    <h1>Manage member</h1>
   <div class="container">
        <div class="options">
            <a class="option" href="addMember.php?fromManageMember=true">Add a Member</a></br>
            <a class="option" href="modifyMember.php?fromManageMember=true">Modify Member details</a></br>
            <a class="option" href="removeMember.php?fromManageMember=true">Remove Member</a></br>
			<a class="option" href="viewMemberPoint.php?fromManageMember=true">View Member Point</a></br>
			<a class="option" href="GrantMemberReward.php?fromManageMember=true">Grant Member Reward</a>
        </div>
</body>
</html>

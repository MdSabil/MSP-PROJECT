			<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
$host = 'localhost';
$dbname = 'msp';
$username = 'root';
$password = '';
$tableName = 'salesrecor'; // Replace 'your_table_name' with your actual table name
$filename = 'exported_data.csv';

// Create a MySQL database connection
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Select the table and fetch the data
$sql = "SELECT * FROM $tableName";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Create and write to the CSV file
    $file = fopen($filename, "w");

    // Write the header row with column names
    $row = $result->fetch_assoc();
    fputcsv($file, array_keys($row));

    // Write the data rows
    $result->data_seek(0); // Reset the result pointer
    while ($row = $result->fetch_assoc()) {
        fputcsv($file, $row);
    }

    fclose($file);

    // Offer the CSV file for download
    if (file_exists($filename)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filename));
        readfile($filename);
        exit;
    } else {
        echo "File does not exist.";
    }
} else {
    echo "No data found in the table.";
}

// Close the database connection
$conn->close();
?>

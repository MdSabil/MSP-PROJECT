<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
// Database connection parameters
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $member_id = $_POST["member_id"];
    $item_id = $_POST["item_id"];
    $amount = intval($_POST["amount"]);
    $date = $_POST["date"];

    // Check if the member ID exists
    $check_member_sql = "SELECT * FROM members WHERE member_id = ?";
    $check_stmt = $conn->prepare($check_member_sql);
    $check_stmt->bind_param("i", $member_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        // The member ID exists
        $check_stmt->close();

        // Check if the item is available in sufficient quantity and get the price per kg
        $sql = "SELECT item_name, item_amount_in_kg, price_of_1kg FROM items WHERE item_id = ?";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $item_id); // "i" represents an integer parameter

        // Execute the prepared statement
        $stmt->execute();

        // Get the result
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $item_name = $row["item_name"];
            $available_quantity = intval($row["item_amount_in_kg"]); // Ensure it's an integer
            $price_per_kg = floatval($row["price_of_1kg"]); // Ensure it's a floating-point number

            if ($available_quantity >= $amount) {
                // Calculate the total cost and member points
                $total_cost = $price_per_kg * $amount;
                $member_points = $total_cost / 100; // 1/100 of the total cost

                // Deduct the purchased amount from the item table
                $sql_update_item = "UPDATE items SET item_amount_in_kg = item_amount_in_kg - ? WHERE item_id = ?";

                // Prepare the update statement
                $stmt_update_item = $conn->prepare($sql_update_item);
                $stmt_update_item->bind_param("ii", $amount, $item_id); // "ii" represents two integers

                // Execute the update statement
                if ($stmt_update_item->execute()) {
                    // Create a new sales record
                    $sql_insert_sales = "INSERT INTO salesrecor (member_id, item_id, amount, date_purchased, Amount_spent) VALUES (?, ?, ?, ?, ?)";
                    
                    // Prepare the insert statement
                    $stmt_insert_sales = $conn->prepare($sql_insert_sales);
                    $stmt_insert_sales->bind_param("iiisd", $member_id, $item_id, $amount, $date, $total_cost); // "iiisd" represents two integers, a date, and a string
                    
                    // Execute the insert statement
                    if ($stmt_insert_sales->execute()) {
                        echo "Purchase successful. Sales record created. Total cost = $total_cost";

                        // Check if the row with member_id exists in the "member_point" table
                        $check_member_points_sql = "SELECT * FROM member_point WHERE member_id = ?";
                        $check_stmt = $conn->prepare($check_member_points_sql);
                        $check_stmt->bind_param("i", $member_id);

                        $check_stmt->execute();
                        $check_result = $check_stmt->get_result();

                        if ($check_result->num_rows == 0) {
                            // Row doesn't exist, insert it
                            $insert_member_points_sql = "INSERT INTO member_point (member_id, member_point) VALUES (?, ?)";
                            $initial_points = $member_points; // Initial points for a new member
                            $insert_stmt = $conn->prepare($insert_member_points_sql);
                            $insert_stmt->bind_param("id", $member_id, $initial_points);

                            if ($insert_stmt->execute()) {
                                echo " Member Points Row Created: $initial_points";
                            } else {
                                echo "Error creating member points row: " . $insert_stmt->error;
                            }
                            $insert_stmt->close();
                        } else {
                            // Row exists, update it with additional points
                            $update_member_points_sql = "UPDATE member_point SET member_point = member_point + ? WHERE member_id = ?";
                            $update_stmt = $conn->prepare($update_member_points_sql);
                            $update_stmt->bind_param("di", $member_points, $member_id);

                            if ($update_stmt->execute()) {
                                echo " Member Points added: $member_points";
                            } else {
                                echo "Error updating member points: " . $update_stmt->error;
                            }
                            $update_stmt->close();
                        }
                        $check_stmt->close();
                    } else {
                        echo "Error creating sales record: " . $stmt_insert_sales->error;
                    }

                    // Close the insert statement for sales record
                    $stmt_insert_sales->close();
                } else {
                    echo "Error updating item quantity: " . $stmt_update_item->error;
                }

                // Close the update statement
                $stmt_update_item->close();
            } else {
                echo "Insufficient quantity of $item_name available.";
            }
        } else {
            echo "Item not found.";
        }

        // Close the prepared statement for item info
        $stmt->close();
    } else {
        echo "Member not found.";
    }
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Purchase Item</title>
</head>
<body>
    <h2>Purchase Item</h2>
    <form method="post" action="">
        Member ID: <input type="text" name="member_id" required><br>
        Item ID: <input type="text" name="item_id" required><br>
        Amount: <input type="text" name="amount" required><br>
        Date: <input type="date" name="date" required><br>
        <input type="submit" value="Purchase" required>
    </form>
</body>
</html>

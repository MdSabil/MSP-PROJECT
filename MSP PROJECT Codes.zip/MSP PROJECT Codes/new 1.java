package scheduling;

public class EDFScheduler extends AbstractScheduler {
    private AbstractProcess currentRunningProcess = null;

    public EDFScheduler() {
        super("EDFSchedulerThread");
    }

    @Override
    public synchronized void add(AbstractProcess aProcess) {
        // Find the right position to insert the process to maintain sorted order
        int index = 0;
        for (; index < fActiveQueue.size(); index++) {
            if (aProcess.getNextDeadline() < fActiveQueue.get(index).getNextDeadline()) {
                break;
            }
        }
        fActiveQueue.add(index, aProcess);

        // Print scheduling statement when a process is added
        System.out.println(aProcess.getName() + " scheduled with next deadline " + aProcess.getNextDeadline() + " ms");

        // Check if the newly added process should be running
        if (fActiveQueue.get(0) == aProcess) {
            if (currentRunningProcess != null && currentRunningProcess != aProcess) {
                currentRunningProcess.setSuspended();
            }
            aProcess.setRunning();
            currentRunningProcess = aProcess;
        } else {
            aProcess.setSuspended();
        }
    }
    @Override
    public synchronized void remove(AbstractProcess aProcess) {
        aProcess.setInactive();
        fActiveQueue.remove(aProcess);

        // Ensure the first remaining process in the queue is running
        if (!fActiveQueue.isEmpty() && currentRunningProcess != fActiveQueue.get(0)) {
            currentRunningProcess.setSuspended();
            fActiveQueue.get(0).setRunning();
            currentRunningProcess = fActiveQueue.get(0);
            System.out.println(fActiveQueue.get(0).getName() + " scheduled with next deadline " + fActiveQueue.get(0).getNextDeadline() + " ms");

        }
    }
}
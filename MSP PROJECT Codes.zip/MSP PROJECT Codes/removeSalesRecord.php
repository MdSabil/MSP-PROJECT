<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
// Database connection parameters
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variable to hold the sales_record_id
$sales_record_id = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sales_record_id = $_POST["sales_record_id"];

    // Check if the sales_record_id is provided
    if (!empty($sales_record_id)) {
        // Prepare and execute the SQL DELETE query
        $sql = "DELETE FROM salesrecor WHERE sales_record_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $sales_record_id); // "i" represents an integer parameter

        if ($stmt->execute()) {
            echo "Sales record with ID $sales_record_id has been removed.";
        } else {
            echo "Error removing sales record: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Please enter a valid sales_record_id.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Remove Sales Record</title>
</head>
<body>
    <h2>Remove Sales Record</h2>
    <form method="post" action="">
        Sales Record ID: <input type="text" name="sales_record_id" value="<?php echo $sales_record_id; ?>"><br>
        <input type="submit" value="Remove">
    </form>
</body>
</html>

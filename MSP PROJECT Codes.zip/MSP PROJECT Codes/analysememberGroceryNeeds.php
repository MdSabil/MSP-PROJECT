<?php
if (!isset($_GET['fromHomepage']) || $_GET['fromHomepage'] !== 'true') {
    // If the 'fromHomepage' parameter is not set or not 'true', redirect to the homepage
    header('Location: add_previledges.php');
    exit();
}
?>
<?php
// Database connection parameters
$host = 'localhost'; // Your database host
$dbname = 'msp'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check for a successful connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$member_id = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["member_id"])) {
    $member_id = $_POST["member_id"];

    // SQL query to find the item the member has bought the most
    $sql = "SELECT item_id, SUM(amount) AS total_amount
            FROM salesrecor
            WHERE member_id = ?
            GROUP BY item_id
            ORDER BY total_amount DESC
            LIMIT 3";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $member_id); // "i" represents an integer parameter

    // Execute the prepared statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $items = array();
        while ($row = $result->fetch_assoc()) {
            $item_id = $row["item_id"];
            $total_amount = $row["total_amount"];
            $item_name = getItemName($conn, $item_id);
            $items[] = array("item_id" => $item_id, "item_name" => $item_name, "total_amount" => $total_amount);
        }

        echo "Member ID: $member_id<br>";
        echo "<h3>Most Bought Items:</h3>";
        displayItems($items);

    } else {
        echo "No purchase history found for Member ID: $member_id";
    }

    // Close the prepared statement
    $stmt->close();
}

// Function to retrieve item name from the items table
function getItemName($conn, $item_id) {
    $sql = "SELECT item_name FROM items WHERE item_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $item_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["item_name"];
    } else {
        return "Item Not Found";
    }
}

// Function to display items
function displayItems($items) {
    foreach ($items as $index => $item) {
        $item_name = $item["item_name"];
        $total_amount = $item["total_amount"];
        echo "Item " . ($index + 1) . ": $item_name (Item ID: " . $item["item_id"] . ") - Total Amount Bought: $total_amount<br>";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Member Grocery Needs</title>
</head>
<body>
    <h2>Member Grocery Needs Analysis</h2>
    <form method="post" action="">
        Member ID: <input type="text" name="member_id" value="<?php echo $member_id; ?>">
        <input type="submit" value="Analyze">
    </form>
</body>
</html>
